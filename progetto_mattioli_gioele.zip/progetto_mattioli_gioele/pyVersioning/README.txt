------------------------------
- pyVersioning versione beta -

Sviluppato da Mattioli Gioele.

------------------------------

Dipendenze:
installare i pacchetti:
-rpyc
-natsort
si consiglia l'installazione tramite "pip"

------------------------------

Istruzioni:
1. Copiare il contenuto della cartella sul server e sul client.
2. Server: lanciare il file Server.py (dipendenze: Branch.py. Changeset.py, consts.py, Repository.py, uti.py)
3. Client: lanciare il file Client.py (dipendenze: consts.py, uti.py)

-------------------------------

Per maggiori informazioni sull'utilizzo digitare il comando "help" all'avvio del client.